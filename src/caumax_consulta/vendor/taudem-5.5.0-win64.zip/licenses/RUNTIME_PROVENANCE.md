# Runtime privado TauDEM 5.5.0 para Windows x64

Este paquete acompaña a HidroCAUMAX e incluye cinco herramientas oficiales de
TauDEM, sus bibliotecas GDAL/PROJ y Microsoft MPI. Los ejecutables se conservan
sin modificaciones. Se ejecutan como procesos locales independientes de QGIS;
no se instala un servicio, no se cambia PATH global ni se registra software.

## Procedencia

- TauDEM: https://github.com/dtarb/TauDEM/releases/tag/v5.5.0
  y https://hydrology.usu.edu/taudem/taudem5/downloads.html
- Datos GDAL/PROJ: subcarpeta share del instalador oficial TauDEM 5.5.0,
  extraída como archivos, sin ejecutar la instalación.
- Microsoft MPI 10.1.3, versión 10.1.12498.52:
  https://www.microsoft.com/en-us/download/details.aspx?id=105289
- Instalador Microsoft original:
  https://download.microsoft.com/download/7/2/7/72731ebb-b63c-4170-ade7-836966263a8f/msmpisetup.exe
- SHA256 publicado por Microsoft en winget:
  https://github.com/microsoft/winget-pkgs/blob/master/manifests/m/Microsoft/msmpi/10.1.12498.52/Microsoft.msmpi.installer.yaml
  `47443829114d8d8670f77af98939fe876d33eceb35d0ce4e0e85efeec4d87213`.

MPI se extrajo del MSI x64 incrustado en el instalador, abriendo su base de
datos solamente en lectura. No se ejecutó el instalador. Los archivos
mpiexec.exe, smpd.exe, msmpi.dll y msmpires.dll conservan una firma Authenticode
válida de Microsoft. El MSI denomina msmpi64.dll y msmpires64.dll a los dos
archivos de 64 bits; se guardan aquí con sus nombres de carga msmpi.dll y
msmpires.dll, sin alterar sus bytes.

## Licencias y dependencias del equipo

TauDEM se distribuye bajo GPLv3; se incluyen su licencia, atribución y código
fuente original completo en TauDEM/TauDEM-5.5.0-source.zip. Las bibliotecas de
terceros mantienen sus licencias correspondientes en third_party.

Microsoft MPI conserva su propio EULA y avisos de terceros en MicrosoftMPI.
La sección 2.a.i permite distribuir sus archivos binarios dentro de aplicaciones
desarrolladas por el distribuidor, sujeta a las condiciones restantes del EULA.
Microsoft MPI no se relicencia bajo la licencia de HidroCAUMAX o TauDEM.

Este paquete NO incluye ni redistribuye las DLL de Microsoft Visual C++.
Utiliza las bibliotecas ya presentes en la instalación requerida de QGIS o en
Windows. Se ha comprobado el flujo completo con las bibliotecas Visual C++
14.38.33135.0 suministradas con QGIS 3.44.15; todos los símbolos importados por
estas herramientas y sus dependencias están presentes. Esta comprobación no
equivale a certificar cualquier distribución o versión histórica de QGIS.

## Prueba funcional del paquete

Con un MDT sintético GeoTIFF de 256 por 256 celdas y CRS EPSG:25830 se ejecutaron
PitRemove, D8FlowDir, AreaD8, Threshold y StreamNet sin cambiar el MDT original.
Se verificaron siete rasters de salida y una red GeoPackage de 1152 elementos.
El entorno de los procesos solo incluyó bin privado y System32 en PATH, más
GDAL_DATA y PROJ_LIB/PROJ_DATA del paquete. La enumeración de módulos cargados
confirmó MPI privada y ninguna dependencia de HEC-HMS u otra aplicación.
La prueba adicional con DLL de Visual C++ procedentes de QGIS se hizo en una
carpeta de prueba separada; esas copias no forman parte de la distribución.
