# Componentes redistribuidos y código fuente

Los ejecutables TauDEM 5.5.0 y sus bibliotecas se redistribuyen sin cambios desde la distribución oficial:
https://github.com/dtarb/TauDEM/releases/tag/v5.5.0

TauDEM se ejecuta como proceso independiente; no se sustituye su algoritmo. Su código fuente completo está también en TauDEM/TauDEM-5.5.0-source.zip, relativo a este documento.
Los avisos y licencias de los componentes se incluyen en esta carpeta licenses/. Cada componente conserva sus propios términos.
Las bibliotecas libres se enlazan dinámicamente. Sus fuentes correspondientes se ofrecen desde los siguientes servidores de sus proyectos originales:

- TauDEM 5.5.0: https://github.com/dtarb/TauDEM/archive/refs/tags/v5.5.0.zip
- GDAL 3.10.3: https://github.com/OSGeo/gdal/releases/tag/v3.10.3
- GEOS 3.13.0: https://download.osgeo.org/geos/geos-3.13.0.tar.bz2
- libspatialite 5.1.0: https://www.gaia-gis.it/gaia-sins/libspatialite-sources/libspatialite-5.1.0.tar.gz
- FreeXL 2.0.0: https://www.gaia-gis.it/gaia-sins/freexl-sources/freexl-2.0.0.tar.gz
- GNU libiconv 1.18: https://ftp.gnu.org/pub/gnu/libiconv/libiconv-1.18.tar.gz
- libjpeg-turbo 3.1.0: https://github.com/libjpeg-turbo/libjpeg-turbo/releases/tag/3.1.0
- libxml2 2.13.5: https://github.com/GNOME/libxml2/tree/v2.13.5
- xz/liblzma 5.6.3: https://github.com/tukaani-project/xz/releases/tag/v5.6.3
- Expat 2.7.1: https://github.com/libexpat/libexpat/releases/tag/R_2_7_1
- libtiff 4.7.0: https://download.osgeo.org/libtiff/tiff-4.7.0.tar.gz
- json-c 0.18: https://github.com/json-c/json-c/releases/tag/json-c-0.18-20240915
- zlib and minizip 1.3.1: https://github.com/madler/zlib/releases/tag/v1.3.1
- SQLite 3.49.1: https://www.sqlite.org/2025/sqlite-src-3490100.zip

Los binarios Microsoft MPI conservan sus términos, incluidos en MicrosoftMPI/. No quedan relicenciados bajo la GPL de TauDEM. Microsoft Visual C++ no se redistribuye en este paquete: se utilizan las bibliotecas ya disponibles con QGIS o Windows. La procedencia y la prueba de compatibilidad se detallan en RUNTIME_PROVENANCE.md.
Este conjunto se instala en una carpeta privada del usuario. No cambia el PATH global ni las bibliotecas de QGIS.
